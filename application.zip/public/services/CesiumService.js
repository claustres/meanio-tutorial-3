'use strict';

// Service utilisé pour accéder à la librairie Cesium via l'injection de dépendances
angular.module('mean.application').factory('Cesium', [ function() {
    return window.Cesium; // Assume que la librairie est déjà chargée dans la page
  }
]);

