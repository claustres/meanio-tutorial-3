'use strict';

// Contrôleur utilisé pour afficher un chemin sur une carte
angular.module('mean.application').controller('TrackMapController', ['$scope', '$stateParams', 'TrackService', 
  function($scope, $stateParams, TrackService) {
    
    $scope.center = {
      lat: 0,
      lng: 0,
      zoom: 5,
      autoDiscover: true
    };
    $scope.defaults = {
        zoomControlPosition: 'topleft',
        scrollWheelZoom: true
    };
    $scope.layers = { 
        baselayers: [{
          name: 'OpenStreetMap',
          type: 'xyz',
          url: 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
          layerOptions: {
              subdomains: ['a', 'b', 'c'],
              attribution: '© OpenStreetMap contributors',
              continuousWorld: true
          }
        },
        {
            name: 'OpenCycleMap',
            type: 'xyz',
            url: 'http://{s}.tile.opencyclemap.org/cycle/{z}/{x}/{y}.png',
            layerOptions: {
                subdomains: ['a', 'b', 'c'],
                attribution: '© OpenCycleMap contributors - © OpenStreetMap contributors',
                continuousWorld: true
            }
        }],
        overlays: {}
    };

    //Récupère un chemin via son ID
    $scope.findOne = function() {
      TrackService.get({
        trackId: $stateParams.trackId
      }, function(track) {
        $scope.track = track;
        $scope.layers.overlays['track'] =  {
            name: 'track',
            type: 'geoJSON',
            url: 'api/track.GeoJSON/' + track._id
        };
      });
    };
  }
]);
