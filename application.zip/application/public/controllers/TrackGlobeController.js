'use strict';

// Contrôleur utilisé pour afficher un chemin sur un globe 3D
angular.module('mean.application').controller('TrackGlobeController', ['$scope', '$http', '$stateParams', 'TrackService', 'TrackGenerator',
  function($scope, $http, $stateParams, TrackService, TrackGenerator) {
    // Projète au sol la position donnée
    var clampToGround = function(position) {
      var cartographicPosition = new Cesium.Cartographic();
      Cesium.Ellipsoid.WGS84.cartesianToCartographic(position, cartographicPosition);
      // Intersect ground
      var cartographicOrigin = Cesium.Cartographic.clone(cartographicPosition);
      // Make sur we are above everything (Everest is ~8000m)
      cartographicOrigin.height = 20000;
      var origin = new Cesium.Cartesian3();
      Cesium.Ellipsoid.WGS84.cartographicToCartesian(cartographicOrigin, origin);
      var direction = new Cesium.Cartesian3();
      Cesium.Cartesian3.subtract(position, origin, direction);
      Cesium.Cartesian3.normalize(direction, direction);
      var ray = new Cesium.Ray(origin, direction);
      
      var groundPosition = new Cesium.Cartesian3();
      return $scope.viewer.scene.globe.pick(ray, $scope.viewer.scene, groundPosition);
    }

    var getTrackedEntity = function() {
      if (Cesium.defined($scope.lookAt)) {
        $scope.trackedEntity = $scope.viewer.dataSources.get(0).entities.getById($scope.lookAt);
        if (Cesium.defined($scope.trackedEntity)) {
          // Default speed
          $scope.viewer.clock.multiplier = 1;
          // Animate the 'visible' entity, i.e. the icon, because the tracked one is only used for the path
          $scope.trackedEntityIcon = $scope.viewer.dataSources.get(0).entities.getById($scope.lookAt + 'Icon');
        }
      }
    }

    // Load the given source (Czml object or czml/geojson/json/topojson file)
    // The lookAt is the name of the entity to track in the source (if any)
    var loadSource = function(source, lookAt) {
      $scope.lookAt = lookAt;
      
      var dataSource = new Cesium.CzmlDataSource();
      dataSource.load(source, 'Built-in CZML');
      $scope.viewer.dataSources.add(dataSource);
      getTrackedEntity();
      
      $scope.viewer.clock.onTick.addEventListener(function(clock) {
        if ( Cesium.defined($scope.trackedEntity) ) {
          var cartographicPosition = new Cesium.Cartographic();
          var position = $scope.trackedEntity.position.getValue(clock.currentTime);
          Cesium.Ellipsoid.WGS84.cartesianToCartographic(position, cartographicPosition);
          
          // Clamp vehicle icon on ground
          var groundPosition = clampToGround(position);
          // While loading terrain we might have some problems here
          if ( Cesium.defined(groundPosition) ) {
            // Update 3D position
            position = groundPosition;
            Cesium.Ellipsoid.WGS84.cartesianToCartographic(groundPosition, cartographicPosition);
            // Animate the 'visible' entity, i.e. the icon, because the tracked one is only used for the path
            if ( Cesium.defined($scope.trackedEntityIcon) ) {
              $scope.trackedEntityIcon.position = new Cesium.ConstantPositionProperty(groundPosition, Cesium.ReferenceFrame.FIXED);
              var text = 'alt. ' + cartographicPosition.height.toFixed() + ' m\n';
              $scope.trackedEntityIcon._label._text = new Cesium.ConstantProperty(text);
            }
          }
          
          // Compute local frame at position
          var transform = Cesium.Transforms.eastNorthUpToFixedFrame(position);
          // Set view in east-north-up frame
          Cesium.Matrix4.clone(transform, $scope.viewer.scene.camera.transform);
          $scope.viewer.scene.camera.constrainedAxis = Cesium.Cartesian3.UNIT_Z;
        }
      });
    }

    //Récupère un chemin via son ID
    $scope.findOne = function() {
      TrackService.get({
        trackId: $stateParams.trackId
      }, function(track) {
        $scope.track = track;

        // Default position
        $scope.viewer.scene.camera.lookAt(
          new Cesium.Cartesian3(-1500.0, -1500.0, 500.0),
          Cesium.Cartesian3.ZERO,
          Cesium.Cartesian3.UNIT_Z);
        loadSource( TrackGenerator.generateCzml($scope.track.waypoints), "Vehicle");
      });
    };
  }
]).directive("cesium", ['Cesium', function (Cesium) {
  return {
    restrict: "E",
    controllerAs: "TrackGlobeController",
    link: function (scope, element, attributes) {
      var options = {
        //Start in Columbus Viewer
        sceneMode : Cesium.SceneMode.SCENE3D,
        sceneModePicker : false,
        scene3DOnly : true,
        homeButton : false,
        geocoder : false,
        navigationHelpButton : true,
        baseLayerPicker : true
      }
      scope.viewer = new Cesium.Viewer(element[0], options);
      // Set default values for providers
      scope.viewer._baseLayerPicker._viewModel.selectedImagery = scope.viewer._baseLayerPicker._viewModel.imageryProviderViewModels[1];
      scope.viewer._baseLayerPicker._viewModel.selectedTerrain = scope.viewer._baseLayerPicker._viewModel.terrainProviderViewModels[1];
    }
  }
}]);

